use Illuminate\Support\Facades\Http;

$response = Http::get('http://example.com');
