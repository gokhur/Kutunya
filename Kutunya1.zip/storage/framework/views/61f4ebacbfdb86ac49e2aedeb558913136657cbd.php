<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('panel.data.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- header -->

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-behavior="sticky">

<div class="wrapper">
<?php echo $__env->make('panel.data.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- sidebar -->
    <div class="main">
    <?php echo $__env->make('panel.data.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- navbar -->

        <?php echo $__env->yieldContent('content'); ?>

 <!-- content -->

    <?php echo $__env->make('panel.data.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- footer -->
    </div>
</div>
<?php echo $__env->make('panel.data.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- scripts -->


</body>

</html>
<?php /**PATH C:\Users\Gokhur\Kutunya1\resources\views/panel/tema.blade.php ENDPATH**/ ?>